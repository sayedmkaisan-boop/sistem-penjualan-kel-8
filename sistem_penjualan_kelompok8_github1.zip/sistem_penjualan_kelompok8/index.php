<!DOCTYPE html>
<html>
<head>
  <title>Kelompok 8 - Sistem Penjualan</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">
  <h2 class="text-center mb-4">SELAMAT DATANG DI SISTEM PENJUALAN</h2>
  <p class="text-center">Kelompok 8</p>
  <div class="text-center">
    <a href="anggota.php" class="btn btn-primary mt-3">Lihat Anggota Kelompok</a>
  </div>
</div>
</body>
</html>
