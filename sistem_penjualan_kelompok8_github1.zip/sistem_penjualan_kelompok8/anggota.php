<!DOCTYPE html>
<html>
<head>
  <title>Anggota Kelompok 8</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">
  <h2 class="text-center mb-4">ANGGOTA KELOMPOK 8</h2>
  <div class="row row-cols-1 row-cols-md-2 g-4">

    <div class="col"><div class="card p-3 shadow-sm"><h4>SAYED</h4></div></div>
    <div class="col"><div class="card p-3 shadow-sm"><h4>BUNGA</h4></div></div>
    <div class="col"><div class="card p-3 shadow-sm"><h4>RAISUL</h4></div></div>
    <div class="col"><div class="card p-3 shadow-sm"><h4>DINI</h4></div></div>

  </div>
  <div class="text-center mt-4">
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </div>
</div>
</body>
</html>
