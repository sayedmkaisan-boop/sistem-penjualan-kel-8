CREATE DATABASE IF NOT EXISTS db_penjualan;
USE db_penjualan;

CREATE TABLE IF NOT EXISTS menu (
  id_menu INT PRIMARY KEY AUTO_INCREMENT,
  nama_menu VARCHAR(100),
  harga DECIMAL(10,2)
);

INSERT INTO menu (nama_menu, harga) VALUES
('Nasi Goreng', 15000),
('Mie Ayam', 12000),
('Es Teh Manis', 5000);
