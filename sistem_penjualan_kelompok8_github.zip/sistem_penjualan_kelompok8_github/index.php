<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Sistem Penjualan - Kelompok 8</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h1 class="text-center mb-4">Sistem Penjualan - Kelompok 8</h1>
  <div class="row g-4 justify-content-center">
    <div class="col-md-3">
  <div class="card shadow-sm text-center">
    <div class="card-body">
      <h5 class="card-title">SAYED</h5>
      <p class="card-text">Anggota Kelompok 8</p>
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="card shadow-sm text-center">
    <div class="card-body">
      <h5 class="card-title">BUNGA</h5>
      <p class="card-text">Anggota Kelompok 8</p>
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="card shadow-sm text-center">
    <div class="card-body">
      <h5 class="card-title">RAISUL</h5>
      <p class="card-text">Anggota Kelompok 8</p>
    </div>
  </div>
</div>
<div class="col-md-3">
  <div class="card shadow-sm text-center">
    <div class="card-body">
      <h5 class="card-title">DINI</h5>
      <p class="card-text">Anggota Kelompok 8</p>
    </div>
  </div>
</div>
  </div>
</div>
</body>
</html>
