# Sistem Penjualan - Kelompok 8

## Anggota:
- SAYED
- BUNGA
- RAISUL
- DINI

## Cara Menjalankan:
1. Copy folder ini ke htdocs
2. Import sql/db_penjualan.sql ke phpMyAdmin
3. Jalankan via http://localhost/sistem_penjualan_kelompok8
